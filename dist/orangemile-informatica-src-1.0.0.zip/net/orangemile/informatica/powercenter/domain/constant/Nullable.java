package net.orangemile.informatica.powercenter.domain.constant;

public enum Nullable {
	NOTNULL,
	NULL
}
