package net.orangemile.informatica.powercenter.domain.constant;

public enum ObjectType {

	SOURCE,
	TARGET,
	TRANSFORMATION,
	MAPPING,
	MAPPLET
}
