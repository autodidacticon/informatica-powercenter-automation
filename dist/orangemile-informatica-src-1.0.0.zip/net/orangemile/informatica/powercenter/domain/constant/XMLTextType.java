package net.orangemile.informatica.powercenter.domain.constant;

public enum XMLTextType {
	SCHEMA,
	ADAPTER,
	TABLE		
}