package net.orangemile.informatica.powercenter.domain.constant;

public enum ScheduleType {
	ONDEMAND,
	CONTINUOUS,
	ONSERVERINIT
}