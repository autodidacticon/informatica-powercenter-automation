package net.orangemile.informatica.powercenter.domain.constant;

public enum NullCharType {	
	BINARY,
	ASCII
}
