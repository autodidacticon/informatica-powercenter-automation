package net.orangemile.informatica.powercenter.domain.constant;

public enum BoxType {
	SOURCE,
	TARGET, 
	TRANSFORMATION, 
	MAPPLET
}
