package net.orangemile.informatica.powercenter.domain.constant;

public enum SortDirection {
	ASCENDING,
	DESCENDING
}
