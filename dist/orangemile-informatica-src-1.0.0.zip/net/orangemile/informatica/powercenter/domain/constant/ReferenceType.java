package net.orangemile.informatica.powercenter.domain.constant;

public enum ReferenceType {
	GLOBAL,
	LOCAL
}
