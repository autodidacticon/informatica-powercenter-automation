package net.orangemile.informatica.powercenter;

import net.orangemile.informatica.powercenter.domain.TransformField;

public interface TransformFieldCallback {
	
	public boolean add( TransformField field );
	
}